package homepage;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class HomepageTest {
	 WebDriver driver;
	    WebDriverWait wait;

	    @BeforeMethod
	    public void setup() {
	        driver = new ChromeDriver();
	        driver.manage().window().maximize();
	        driver.get("https://hexaclothes.netlify.app/");
	        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	    }

	    @AfterMethod
	    public void tearDown() {
	        driver.quit();
	    }

	    
	    // CATEGORY VALIDATIONS

	    @Test(priority = 1)
	    public void verifyTopRatedCategory() throws Exception {

	        WebElement topRated = wait.until(
	                ExpectedConditions.elementToBeClickable(
	                        By.xpath("//a[@href='/tr']")));

	        System.out.println("Top Rated Displayed : "
	                + topRated.isDisplayed());

	        System.out.println("Top Rated Clickable : "
	                + topRated.isEnabled());

	        topRated.click();

	        System.out.println(
	                "PASS : Top Rated Category Opened");

	        Thread.sleep(2000);
	    }

	    @Test(priority = 2)
	    public void verifyKidsWearCategory() throws Exception {

	        WebElement kids = wait.until(
	                ExpectedConditions.elementToBeClickable(
	                        By.xpath("//*[@id='root']/div[1]/div[1]/ul/li[3]/a")));

	        System.out.println("Kids Wear Displayed : "
	                + kids.isDisplayed());

	        kids.click();

	        System.out.println(
	                "PASS : Kids Wear Category Opened");

	        Thread.sleep(2000);
	    }

	    @Test(priority = 3)
	    public void verifyMensWearCategory() throws Exception {

	        WebElement mens = wait.until(
	                ExpectedConditions.elementToBeClickable(
	                        By.xpath("//*[@id='root']/div[1]/div[1]/ul/li[4]/a")));

	        System.out.println("Mens Wear Displayed : "
	                + mens.isDisplayed());

	        mens.click();

	        System.out.println(
	                "PASS : Mens Wear Category Opened");

	        Thread.sleep(2000);
	    }

	    @Test(priority = 4)
	    public void verifyWomensWearCategory() throws Exception {

	        WebElement womens = wait.until(
	                ExpectedConditions.elementToBeClickable(
	                        By.xpath("//*[@id='root']/div[1]/div[1]/ul/li[5]/a")));

	        System.out.println("Women Wear Displayed : "
	                + womens.isDisplayed());

	        womens.click();

	        System.out.println(
	                "PASS : Women Wear Category Opened");

	        Thread.sleep(2000);
	    }

	    @Test(priority = 5)
	    public void verifyAllProductsCategory() throws Exception {

	        WebElement allProducts = wait.until(
	                ExpectedConditions.elementToBeClickable(
	                        By.xpath("//*[@id='root']/div[1]/div[1]/ul/li[6]/a")));

	        allProducts.click();

	        System.out.println(
	                "PASS : All Products Opened");

	        Thread.sleep(2000);
	    }

	    
	    // HEADER ICON VALIDATIONS

	    @Test(priority = 6)
	    public void verifyWishlistPage() throws Exception {

	        WebElement wishlist = wait.until(
	                ExpectedConditions.elementToBeClickable(
	                        By.cssSelector("a[href='/wishlist']")));

	        System.out.println("Wishlist Displayed : "
	                + wishlist.isDisplayed());

	        wishlist.click();

	        System.out.println(
	                "PASS : Wishlist Page Opened");

	        Thread.sleep(2000);
	    }

	    @Test(priority = 7)
	    public void verifyCartPage() throws Exception {

	        WebElement cart = wait.until(
	                ExpectedConditions.elementToBeClickable(
	                        By.cssSelector("a[href='/cart']")));

	        System.out.println("Cart Displayed : "
	                + cart.isDisplayed());

	        cart.click();

	        System.out.println(
	                "PASS : Cart Page Opened");

	        Thread.sleep(2000);
	    }

	    @Test(priority = 8)
	    public void verifyLoginPage() throws Exception {

	        WebElement login = wait.until(
	                ExpectedConditions.elementToBeClickable(
	                        By.cssSelector("a[href='/login'] button")));

	        System.out.println("Login Displayed : "
	                + login.isDisplayed());

	        login.click();

	        System.out.println(
	                "PASS : Login Page Opened");

	        Thread.sleep(2000);
	    }

	    
	    // SUBSCRIPTION VALIDATIONS

	    @Test(priority = 9)
	    public void verifyValidSubscription() throws Exception {

	        WebElement email =
	                driver.findElement(By.xpath(
	                        "//*[@id='root']/div[1]/div[6]/div/div/input"));

	        email.sendKeys("sreelakshmi@gmail.com");

	        WebElement subscribe =
	                driver.findElement(By.xpath(
	                        "//*[@id='root']/div[1]/div[6]/div/div/button"));

	        subscribe.click();

	        System.out.println(
	                "PASS : Valid Email Subscription Submitted");

	        Thread.sleep(2000);
	    }

	    @Test(priority = 10)
	    public void verifyInvalidSubscription() throws Exception {

	        WebElement email =
	                driver.findElement(By.xpath(
	                        "//*[@id='root']/div[1]/div[6]/div/div/input"));

	        email.sendKeys("abc");

	        WebElement subscribe =
	                driver.findElement(By.xpath(
	                        "//*[@id='root']/div[1]/div[6]/div/div/button"));

	        subscribe.click();

	        System.out.println(
	                "PASS : Invalid Email Validation Checked");

	        Thread.sleep(2000);
	    }

	    
	    // FOOTER VALIDATIONS

	    @Test(priority = 11)
	    public void verifyFooterIconsDisplayed() {

	        List<WebElement> socialIcons =
	                driver.findElements(By.tagName("svg"));

	        System.out.println(
	                "Footer Social Icons Found : "
	                        + socialIcons.size());

	        if (socialIcons.size() > 0) {
	            System.out.println(
	                    "PASS : Footer Icons Displayed");
	        } else {
	            System.out.println(
	                    "FAIL : Footer Icons Not Displayed");
	        }
	    }
	}

