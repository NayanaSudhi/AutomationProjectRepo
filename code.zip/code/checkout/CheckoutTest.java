package checkout;

import java.time.Duration;
import java.util.List;

import org.junit.platform.suite.api.Select;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class CheckoutTest {
	WebDriver driver;
	 WebDriverWait wait;

	    @BeforeClass
	    public void setup() {

	        driver = new ChromeDriver();
	        driver.manage().window().maximize();
	        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

	        wait = new WebDriverWait(driver, Duration.ofSeconds(10));

	        driver.get("https://hexaclothes.netlify.app/");
	    }

	    @Test(priority = 1)
	    public void addThreeProductsAndNavigateCheckout() throws Exception {

	        driver.findElement(By.xpath(
	                "//*[@id='root']/div[1]/div[1]/ul/li[6]/a"))
	                .click();

	        Thread.sleep(3000);

	        List<WebElement> addButtons =
	                driver.findElements(By.xpath("//button[contains(text(),'Add')]"));

	        int count = 0;

	        for (WebElement btn : addButtons) {

	            btn.click();
	            count++;

	            System.out.println(
	                    "Product Added To Cart : " + count);

	            Thread.sleep(1000);

	            if (count == 3)
	                break;
	        }

	        System.out.println(
	                "Expected Products : 3");
	        System.out.println(
	                "Actual Products   : " + count);

	        Assert.assertEquals(count, 3);

	        System.out.println("PASS : 3 Products Added");

	        driver.findElement(By.xpath(
	                "//*[@id='root']/div[1]/nav/div[2]/a[2]/svg"))
	                .click();

	        Thread.sleep(2000);

	        System.out.println(
	                "PASS : Cart Page Opened");

	        driver.findElement(By.xpath(
	                "//*[@id='root']/div[1]/div[2]/div[2]/button"))
	                .click();

	        Thread.sleep(3000);

	        System.out.println(
	                "PASS : Checkout Page Opened");
	    }

	    @Test(priority = 2)
	    public void verifyCheckoutHeading() {

	        try {

	            WebElement heading =
	                    driver.findElement(By.xpath(
	                            "//*[contains(text(),'Checkout')]"));

	            System.out.println(
	                    "Heading Displayed : "
	                            + heading.isDisplayed());

	            Assert.assertTrue(
	                    heading.isDisplayed());

	            System.out.println(
	                    "PASS : Checkout Heading Displayed");

	        } catch (Exception e) {

	            System.out.println(
	                    "FAIL : Checkout Heading Missing");
	        }
	    }

	    @Test(priority = 3)
	    public void verifyOrderSummary() {

	        try {

	            WebElement summary =
	                    driver.findElement(By.xpath(
	                            "//*[contains(text(),'Order Summary')]"));

	            System.out.println(
	                    "Order Summary Present : "
	                            + summary.isDisplayed());

	            Assert.assertTrue(summary.isDisplayed());

	            System.out.println(
	                    "PASS : Order Summary Displayed");

	        } catch (Exception e) {

	            System.out.println(
	                    "FAIL : Order Summary Missing");
	        }
	    }

	    @Test(priority = 4)
	    public void verifyShippingPaymentValidData() {


	        driver.findElement(By.name("firstName"))
	                .sendKeys("Sreelakshmi");

	        driver.findElement(By.name("lastName"))
	                .sendKeys("Sreenivasan");

	        driver.findElement(By.name("email"))
	                .sendKeys("sreelakshmi@gmail.com");

	        driver.findElement(By.name("address"))
	                .sendKeys("Sree House");

	        driver.findElement(By.name("city"))
	                .sendKeys("Kannur");

	        driver.findElement(By.name("postalCode"))
	                .sendKeys("670301");

	        driver.findElement(By.name("cardNumber"))
	                .sendKeys("4242424242424242");

	        driver.findElement(By.name("cardHolder"))
	                .sendKeys("Sreelakshmi");

	        driver.findElement(By.name("expiryDate"))
	                .sendKeys("12/34");

	        driver.findElement(By.name("cvv"))
	                .sendKeys("321");

	        System.out.println(
	                "PASS : All Valid Data Entered");
	    }

	    @Test(priority = 5)
	    public void verifyPlaceOrderButton() {


	        try {

	            WebElement orderButton =
	                    driver.findElement(
	                            By.xpath("//button[contains(text(),'Place')]"));

	            System.out.println(
	                    "Button Enabled : "
	                            + orderButton.isEnabled());

	            orderButton.click();

	            Thread.sleep(3000);

	            System.out.println(
	                    "PASS : Place Order Clicked");

	        } catch (Exception e) {

	            System.out.println(
	                    "FAIL : Place Order Failed");
	        }
	    }

	    @Test(priority = 6)
	    public void verifyEmptyFullNameValidation() {

	        driver.navigate().refresh();

	        try {

	            WebElement firstName =
	                    driver.findElement(By.name("firstName"));

	            firstName.clear();

	            driver.findElement(
	                    By.xpath("//button[contains(text(),'Place')]"))
	                    .click();

	            System.out.println(
	                    "Expected : Error Message");

	            System.out.println(
	                    "Actual   : Validation Checked");

	        } catch (Exception e) {

	            System.out.println(
	                    "FAIL : Validation Not Found");
	        }
	    }

	    @Test(priority = 7)
	    public void verifyInvalidEmailValidation() {


	        try {

	            driver.findElement(By.name("email"))
	                    .clear();

	            driver.findElement(By.name("email"))
	                    .sendKeys("abc.com");

	            driver.findElement(
	                    By.xpath("//button[contains(text(),'Place')]"))
	                    .click();

	            System.out.println(
	                    "Entered Email : abc.com");

	            System.out.println(
	                    "Expected : Error Message");

	            System.out.println(
	                    "Validation Executed");

	        } catch (Exception e) {

	            System.out.println(
	                    "FAIL");
	        }
	    }

	    @Test(priority = 8)
	    public void verifyInvalidCardNumber() {


	        try {

	            WebElement card =
	                    driver.findElement(
	                            By.name("cardNumber"));

	            card.clear();

	            card.sendKeys("aaaaaaaaaaaa");

	            driver.findElement(
	                    By.xpath("//button[contains(text(),'Place')]"))
	                    .click();

	            System.out.println(
	                    "Card Number : aaaaaaaaaaaa");

	            System.out.println(
	                    "Expected : Validation");

	            System.out.println(
	                    "Validation Checked");

	        } catch (Exception e) {

	            System.out.println(
	                    "FAIL");
	        }
	    }

	    @Test(priority = 9)
	    public void verifyInvalidPostalCode() {


	        try {

	            WebElement pin =
	                    driver.findElement(
	                            By.name("postalCode"));

	            pin.clear();

	            pin.sendKeys("0000000");

	            driver.findElement(
	                    By.xpath("//button[contains(text(),'Place')]"))
	                    .click();

	            System.out.println(
	                    "Postal Code : 0000000");

	            System.out.println(
	                    "Expected : Validation");

	            System.out.println(
	                    "Validation Checked");

	        } catch (Exception e) {

	            System.out.println(
	                    "FAIL");
	        }
	    }

	    @Test(priority = 10)
	    public void verifyEmptyFieldsValidation() {

	        try {

	            driver.findElement(By.name("firstName"))
	                    .clear();

	            driver.findElement(By.name("email"))
	                    .clear();

	            driver.findElement(By.name("city"))
	                    .clear();

	            driver.findElement(By.name("postalCode"))
	                    .clear();

	            driver.findElement(
	                    By.xpath("//button[contains(text(),'Place')]"))
	                    .click();

	            System.out.println(
	                    "Expected : Error Messages");

	            System.out.println(
	                    "Actual   : Validation Triggered");

	        } catch (Exception e) {

	            System.out.println(
	                    "FAIL");
	        }
	    }

	    @AfterClass
	    public void tearDown() {

	        System.out.println(
	                "\n========== TEST EXECUTION COMPLETED ==========");

	        driver.quit();
	    }

   
    
}
