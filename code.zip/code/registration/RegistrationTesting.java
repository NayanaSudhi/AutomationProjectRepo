package registration;

import org.testng.annotations.Test;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

public class RegistrationTesting {
	WebDriver driver;
	
	 @Test(priority = 1)
	    public void verifyEmptyNameField() {

	       // driver.navigate().refresh();

	        driver.findElement(By.name("email"))
	                .sendKeys("sreelakshmi@gmail.com");

	        driver.findElement(By.name("password"))
	                .sendKeys("sree@12345");

	        driver.findElement(By.name("confirmPassword"))
	                .sendKeys("sree@12345");

	        driver.findElement(
	                By.xpath("//button[contains(text(),'Register')]"))
	                .click();

	        System.out.println(
	                "PASS : Error message displayed for empty name field");
	    }

	    @Test(priority = 2)
	    public void verifyAlreadyRegisteredEmail() {

	        //driver.navigate().refresh();

	        driver.findElement(By.name("name"))
	                .sendKeys("Sreelakshmi");

	        driver.findElement(By.name("email"))
	                .sendKeys("sreelakshmi@gmail.com");

	        driver.findElement(By.name("password"))
	                .sendKeys("sree@12345");

	        driver.findElement(By.name("confirmPassword"))
	                .sendKeys("sree@12345");

	        driver.findElement(
	                By.xpath("//button[contains(text(),'Register')]"))
	                .click();

	        System.out.println(
	                "FAIL : Error message for registered email is not displayed");
	    }

	    @Test(priority = 3)
	    public void verifyEmptyFormSubmission() {


	        driver.findElement(
	                By.xpath("//button[contains(text(),'Register')]"))
	                .click();

	        System.out.println(
	                "PASS : Error messages displayed for empty fields");
	    }

	    @Test(priority = 4)
	    public void verifyPasswordVisibilityToggle() {


	        WebElement password =
	                driver.findElement(By.name("password"));

	        password.sendKeys("sree@12345");

	        WebElement eyeIcon =
	                driver.findElement(
	                        By.xpath("//*[@id=\"root\"]/div[1]/div[2]/form/div[3]/button/svg"));

	        eyeIcon.click();

	        System.out.println(
	                "PASS : Password show/hide functionality works");
	    }

	    @Test(priority = 5)
	    public void verifyRegisterButton() {

	        driver.findElement(By.name("name"))
	                .sendKeys("Sreelakshmi");

	        driver.findElement(By.name("email"))
	                .sendKeys("sree123@gmail.com");

	        driver.findElement(By.name("password"))
	                .sendKeys("sree@12345");

	        driver.findElement(By.name("confirmPassword"))
	                .sendKeys("sree@12345");

	        driver.findElement(
	                By.xpath("//button[contains(text(),'Register')]"))
	                .click();

	        System.out.println(
	                "PASS : Register button is clickable and works");
	    }

	    @Test(priority = 6)
	    public void verifyAlreadyHaveAccountMessage() {

	        boolean message =
	                driver.getPageSource()
	                        .contains("Already have an account");

	        if(message) {

	            System.out.println(
	                    "PASS : Already have an account message displayed");
	        }
	        else {

	            System.out.println(
	                    "FAIL : Message not displayed");
	        }

	        Assert.assertTrue(message);
	    }

	    @Test(priority = 7)
	    public void verifyLoginHereLink() {

	        WebElement loginLink =
	                driver.findElement(
	                        By.partialLinkText("Login"));

	        loginLink.click();

	        String currentUrl =
	                driver.getCurrentUrl();

	        if(currentUrl.contains("login")) {

	            System.out.println(
	                    "PASS : Login Here link redirects to Login page");
	        }
	        else {

	            System.out.println(
	                    "FAIL : Login page not opened");
	        }

	        Assert.assertTrue(
	                currentUrl.contains("login"));
	    }
	    
	    @AfterClass
	    public void closeBrowser() {

	        driver.quit();
	  }


	
	 @BeforeClass
	    public void setup() {

	        driver = new ChromeDriver();
	        driver.manage().window().maximize();
	        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

	        driver.get("https://hexaclothes.netlify.app/");
	        driver.findElement(By.xpath("//*[@id=\"root\"]/div[1]/nav/div[2]/a[3]/button")).click();
	        driver.findElement(By.xpath("//*[@id=\"root\"]/div[1]/div[2]/div/p/a")).click();
	    }

	   
}
