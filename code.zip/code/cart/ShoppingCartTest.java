package cart;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class ShoppingCartTest {
WebDriver driver;
	
	@Test(priority = 1)
	public void addProductsToCart() {

		driver.findElements(By.xpath("//*[@id=\"root\"]/div[1]/div[1]/ul/li[6]/a"));

	    List<WebElement> addButtons =
	            driver.findElements(By.xpath("//button[contains(text(),'Add')]"));

	    for(int i=0; i<3; i++) {
	        addButtons.get(i).click();
	    }

	    driver.findElements(By.xpath("//*[@id=\"root\"]/div[1]/nav/div[2]/a[2]/svg/path"));

	    List<WebElement> products =
	            driver.findElements(By.tagName("img"));

	    if(products.size() >= 3) {
	        System.out.println("PASS : 3 Products Added To Cart");
	    }
	    else {
	        System.out.println("FAIL : Products Not Added To Cart");
	        Assert.fail();
	    }
	}
	
	@Test(priority = 2)
	public void verifyCartPageLoadsSuccessfully() {

	    boolean cartPage =
	            driver.getCurrentUrl().contains("cart");

	    System.out.println("Cart Page Displayed : " + cartPage);

	    Assert.assertTrue(cartPage);

	    System.out.println("PASS : Cart Page Loaded Successfully");
	}
	
	@Test(priority = 3)
	public void verifyQuantityDisplayed() {

	    WebElement plus =
	            driver.findElement(By.xpath("//*[text()='+']"));

	    WebElement minus =
	            driver.findElement(By.xpath("//*[text()='-']"));

	    System.out.println("Plus Button Displayed : "
	            + plus.isDisplayed());

	    System.out.println("Minus Button Displayed : "
	            + minus.isDisplayed());

	    Assert.assertTrue(plus.isDisplayed());
	    Assert.assertTrue(minus.isDisplayed());

	    System.out.println("PASS : Quantity Controls Displayed");
	}
	@Test(priority = 4)
	public void verifyIncreaseQuantity() {

	    WebElement qty =
	            driver.findElement(By.xpath("//input"));

	    String before = qty.getAttribute("value");

	    driver.findElement(By.xpath("//*[text()='+']")).click();

	    String after = qty.getAttribute("value");

	    System.out.println("Quantity Before : " + before);
	    System.out.println("Quantity After  : " + after);

	    Assert.assertNotEquals(before, after);

	    System.out.println("PASS : Quantity Increased");
	}
	
	@Test(priority = 5)
	public void verifyDecreaseQuantity() {

	    WebElement qtyField =
	            driver.findElement(By.xpath("//input[@type='number']"));

	    int beforeQty =
	            Integer.parseInt(qtyField.getAttribute("value"));

	    driver.findElement(By.xpath("//*[text()='-']")).click();

	    int afterQty =
	            Integer.parseInt(qtyField.getAttribute("value"));

	    System.out.println("Quantity Before : " + beforeQty);
	    System.out.println("Quantity After  : " + afterQty);

	    if(afterQty < beforeQty) {
	        System.out.println("PASS : Quantity Decreased");
	    } else {
	        System.out.println("FAIL : Quantity Not Decreased");
	        Assert.fail();
	    }
	}
	
	@Test(priority = 6)
	public void verifyTotalPriceCalculation() {

	    WebElement body =
	            driver.findElement(By.tagName("body"));

	    boolean cartSummaryDisplayed =
	            body.getText().contains("Summary");

	    boolean totalPriceDisplayed =
	            body.getText().contains("Total");

	    System.out.println("Cart Summary Displayed : "
	            + cartSummaryDisplayed);

	    System.out.println("Total Price Displayed  : "
	            + totalPriceDisplayed);

	    if(cartSummaryDisplayed && totalPriceDisplayed) {

	        System.out.println(
	                "PASS : Total Price Calculated Correctly");

	    } else {

	        System.out.println(
	                "FAIL : Total Price Not Displayed");

	        Assert.fail();
	    }
	}
	
	@Test(priority = 7)
	public void verifyRemoveProduct() {

	    int beforeCount =
	            driver.findElements(By.tagName("img")).size();

	    WebElement removeBtn =
	            driver.findElement(
	                    By.xpath("//*[contains(text(),'Remove')]"));

	    removeBtn.click();

	    int afterCount =
	            driver.findElements(By.tagName("img")).size();

	    System.out.println(
	            "Products Before Removal : "
	                    + beforeCount);

	    System.out.println(
	            "Products After Removal  : "
	                    + afterCount);

	    if(afterCount < beforeCount) {

	        System.out.println(
	                "PASS : Product Removed Successfully");

	    } else {

	        System.out.println(
	                "FAIL : Product Not Removed");

	        Assert.fail();
	    }
	}
	
	@Test(priority = 8)
	public void verifyCartCountUpdate() {

	    int beforeCount = 3; // Store before removal

	    int afterCount =
	            driver.findElements(By.tagName("img")).size();

	    System.out.println(
	            "Cart Count Before : "
	                    + beforeCount);

	    System.out.println(
	            "Cart Count After  : "
	                    + afterCount);

	    if(afterCount == beforeCount - 1) {

	        System.out.println(
	                "PASS : Cart Count Updated Correctly");

	    } else {

	        System.out.println(
	                "FAIL : Cart Count Not Updated");

	        Assert.fail();
	    }
	}
	
	@Test(priority = 9)
	public void verifyEmptyCartMessage() {

	    List<WebElement> removeButtons =
	            driver.findElements(
	                    By.xpath("//*[contains(text(),'Remove')]"));

	    while(removeButtons.size() > 0) {

	        removeButtons.get(0).click();

	        removeButtons =
	                driver.findElements(
	                        By.xpath("//*[contains(text(),'Remove')]"));
	    }

	    boolean emptyMessage =
	            driver.findElement(By.tagName("body"))
	                    .getText()
	                    .toLowerCase()
	                    .contains("empty");

	    System.out.println(
	            "Empty Cart Message Displayed : "
	                    + emptyMessage);

	    if(emptyMessage) {

	        System.out.println(
	                "PASS : Empty Cart Message Verified");

	    } else {

	        System.out.println(
	                "FAIL : Empty Cart Message Not Displayed");

	        Assert.fail();
	    }
	}
	
	@Test(priority = 10)
	public void verifyCheckoutButton() {

	    WebElement checkoutBtn =
	            driver.findElement(
	                    By.xpath("//*[contains(text(),'Checkout')]"));

	    boolean displayed =
	            checkoutBtn.isDisplayed();

	    boolean enabled =
	            checkoutBtn.isEnabled();

	    System.out.println(
	            "Checkout Button Displayed : "
	                    + displayed);

	    System.out.println(
	            "Checkout Button Enabled   : "
	                    + enabled);

	    if(displayed && enabled) {

	        System.out.println(
	                "PASS : Checkout Button Working");

	    } else {

	        System.out.println(
	                "FAIL : Checkout Button Not Working");

	        Assert.fail();
	    }
	}
	
	@Test(priority = 11)
	public void verifyCheckoutWithoutLogin() {

	    WebElement checkoutBtn =
	            driver.findElement(
	                    By.xpath("//*[contains(text(),'Checkout')]"));

	    checkoutBtn.click();

	    String currentUrl =
	            driver.getCurrentUrl();

	    boolean redirected =
	            currentUrl.contains("login")
	            || currentUrl.contains("register");

	    System.out.println(
	            "Current URL : "
	                    + currentUrl);

	    System.out.println(
	            "Redirected To Login : "
	                    + redirected);

	    if(redirected) {

	        System.out.println(
	                "PASS : Checkout Restricted For Guest User");

	    } else {

	        System.out.println(
	                "FAIL : User Able To Checkout Without Login");

	        Assert.fail();
	    }
	}
	 @AfterClass
	    public void closeBrowser() {

	        driver.quit();
	  }


	
	 @BeforeClass
	    public void setup() {

	        driver = new ChromeDriver();
	        driver.manage().window().maximize();
	        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

	        driver.get("https://hexaclothes.netlify.app/");
	        
	       
	    }

}
