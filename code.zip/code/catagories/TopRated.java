package catagories;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class TopRated {
	
	 WebDriver driver;
	 
	  @Test(priority = 1)
	    public void verifyTopSellingCaption() {

	        boolean displayed =
	                driver.getPageSource().contains("Top Selling Products for you");

	        System.out.println("Top Selling Products Caption Displayed : "
	                + displayed);

	        Assert.assertTrue(displayed);
	    }
	  
	  @Test(priority = 2)
	    public void verifyTopRatedTitle() {

	        WebElement title =
	                driver.findElement(By.tagName("h1"));

	        System.out.println("Top Rated Title : "
	                + title.getText());

	        Assert.assertTrue(title.isDisplayed());
	    }
	  
	  @Test(priority = 3)
	    public void verifyProductImages() {

	        List<WebElement> images =
	                driver.findElements(By.tagName("img"));

	        System.out.println(" Images displayed  : "
	                + images.size());

	        Assert.assertTrue(images.size() > 0);
	    }
	  
	  @Test(priority = 4)
	    public void verifyProductNames() {

	        List<WebElement> products =
	                driver.findElements(By.tagName("h3"));

	        for (WebElement product : products) {

	            System.out.println("Product Name : "
	                    + product.getText());
	        }

	        Assert.assertTrue(products.size() > 0);
	    }
	  
	  @Test(priority = 5)
	    public void verifyPriceColourRating() {

	        String pageSource = driver.getPageSource();

	        boolean rating = pageSource.contains("rating");

	        System.out.println("Price/Rating/colur Information Present : "
	                + rating);

	        Assert.assertTrue(pageSource.length() > 0);
	    }
	  
	  @Test(priority = 6)
	    public void verifyAddToCartButton() {

	        List<WebElement> buttons =
	                driver.findElements(
	                        By.xpath("//button[contains(text(),'Add')]"));

	        if (buttons.size() > 0) {

	            buttons.get(0).click();

	            System.out.println(
	                    "PASS : Add To Cart Button Clicked");
	        }
	        else {

	            System.out.println(
	                    "FAIL : Add To Cart Button Not clickable");
	        }

	        Assert.assertTrue(buttons.size() > 0);
	    }
	  
	  @Test(priority = 7)
	    public void verifyFooterDisplayed() {

	        WebElement footer =
	                driver.findElement(By.tagName("footer"));

	        System.out.println("Footer Displayed : "
	                + footer.isDisplayed());

	        Assert.assertTrue(footer.isDisplayed());
	    }
	  
	  @Test(priority = 8)
	  public void verifyCategoriesDisplayed() {

	      WebElement mens =
	              driver.findElement(By.linkText("Mens"));

	      WebElement womens =
	              driver.findElement(By.linkText("Women"));

	      WebElement kids =
	              driver.findElement(By.linkText("Kids"));

	      WebElement allProducts =
	              driver.findElement(By.linkText("All Products"));

	      System.out.println("Mens : " + mens.isDisplayed());
	      System.out.println("Women : " + womens.isDisplayed());
	      System.out.println("Kids : " + kids.isDisplayed());
	      System.out.println("All Products : " + allProducts.isDisplayed());

	      Assert.assertTrue(mens.isDisplayed());
	      Assert.assertTrue(womens.isDisplayed());
	      Assert.assertTrue(kids.isDisplayed());
	      Assert.assertTrue(allProducts.isDisplayed());
	  }
	  
	  @Test(priority = 9)
	    public void verifyNavigationToOtherCategory() {

	        List<WebElement> links =
	                driver.findElements(By.tagName("a"));

	        if (links.size() > 0) {

	            links.get(0).click();

	            System.out.println(
	                    "PASS : Navigate to other category is Successful");
	        }

	        Assert.assertTrue(true);
	    }
	  
	  @Test(priority = 10)
	    public void verifyNavigationToProductDetailsPage() {

	        List<WebElement> images =
	                driver.findElements(By.tagName("img"));

	        if (images.size() > 0) {

	            images.get(0).click();

	            System.out.println(
	                    "PASS : Product details page displayed");
	        }

	        Assert.assertTrue(true);
	    }

	    @AfterClass
	    public void closeBrowser() {

	        driver.quit();
	    }
	

  @BeforeClass
  public void setup() {

      driver = new ChromeDriver();
      driver.manage().window().maximize();
      driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

      driver.get("https://hexaclothes.netlify.app/");
      driver.findElement(By.xpath("//*[@id=\"root\"]/div[1]/div[1]/ul/li[2]/a")).click();
  }
}
