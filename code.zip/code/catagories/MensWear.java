package catagories;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class MensWear {
	WebDriver driver;
	
	@Test(priority = 1)
	public void verifyProductDetails() {

	    List<WebElement> products =
	            driver.findElements(By.tagName("img"));

	    if(products.size() > 0) {

	        System.out.println(
	                "PASS : Product details are displayed correctly");
	    }
	    else {

	        System.out.println(
	                "FAIL : Product details are not displayed");
	    }

	    Assert.assertTrue(products.size() > 0);
	}
	
	@Test(priority = 2)
	public void verifyAddToCartButton() {

	    List<WebElement> addButtons =
	            driver.findElements(
	                    By.xpath("//button[contains(text(),'Add')]"));

	    if(addButtons.size() > 0) {

	        addButtons.get(0).click();

	        System.out.println(
	                "PASS : Add To Cart button is functional and product is added");
	    }
	    else {

	        System.out.println(
	                "FAIL : Add To Cart button not found");
	    }

	    Assert.assertTrue(addButtons.size() > 0);
	}
	
	@Test(priority = 3)
	public void verifyProductDetailsPage() {

	    String currentUrl =
	            driver.getCurrentUrl();

	    List<WebElement> images =
	            driver.findElements(By.tagName("img"));

	    if(images.size() > 0) {

	        images.get(0).click();

	        if(driver.getCurrentUrl().equals(currentUrl)) {

	            System.out.println(
	                    "FAIL : Product details page is not available");
	        }
	        else {

	            System.out.println(
	                    "PASS : Product details page opened");
	        }
	    }
	}
	
	@Test(priority = 4)
	public void verifyWishlistButton() {

	    List<WebElement> wishlistButtons =
	            driver.findElements(
	                    By.xpath("//*[contains(@class,'wish')]"));

	    if(wishlistButtons.size() > 0) {

	        wishlistButtons.get(0).click();

	        System.out.println(
	                "PASS : Wishlist button is clickable and product added");
	    }
	    else {

	        System.out.println(
	                "FAIL : Wishlist button not found");
	    }

	    Assert.assertTrue(wishlistButtons.size() > 0);
	}
	
	@Test(priority = 5)
	public void verifyCartAndWishlistWithoutLogin() {

	    boolean cartAdded = false;
	    boolean wishlistAdded = false;

	    try {

	        driver.findElements(
	                By.xpath("//button[contains(text(),'Add')]"))
	                .get(0).click();

	        cartAdded = !driver.getCurrentUrl()
	                .contains("login");

	    } catch (Exception e) {

	        cartAdded = false;
	    }

	    driver.navigate().back();

	    try {

	        driver.findElements(
	                By.xpath("//*[contains(@class,'wish')]"))
	                .get(0).click();

	        wishlistAdded = !driver.getCurrentUrl()
	                .contains("login");

	    } catch (Exception e) {

	        wishlistAdded = false;
	    }

	    if(cartAdded && wishlistAdded) {

	        System.out.println(
	                "PASS : User can add products without login");
	    }
	    else {

	        System.out.println(
	                "FAIL : Wishlist cannot be added without login");
	    }
	}
	
	@Test(priority = 6)
	public void verifyFooterDisplayed() {

	    WebElement footer =
	            driver.findElement(By.tagName("footer"));

	    if(footer.isDisplayed()) {

	        System.out.println(
	                "PASS : Footer is displayed");
	    }

	    Assert.assertTrue(footer.isDisplayed());
	}
	
	@Test(priority = 9)
	public void verifyWishlistRedirectToLogin() {

	    List<WebElement> wishlistButtons =
	            driver.findElements(
	                    By.xpath("//*[contains(@class,'wish')]"));

	    if(wishlistButtons.size() > 0) {

	        wishlistButtons.get(0).click();

	        String url =
	                driver.getCurrentUrl();

	        if(url.contains("login")) {

	            System.out.println(
	                    "PASS : User is redirected to Login page");
	        }
	        else {

	            System.out.println(
	                    "FAIL : Login page is not opened");
	        }
	    }
	}

    @AfterClass
    public void closeBrowser() {

        driver.quit();
    }
	
	 @BeforeClass
	  public void setup() {

	      driver = new ChromeDriver();
	      driver.manage().window().maximize();
	      driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

	      driver.get("https://hexaclothes.netlify.app/");
	      driver.findElement(By.xpath("//*[@id=\"root\"]/div[1]/div[1]/ul/li[4]/a")).click();
	  }
}
