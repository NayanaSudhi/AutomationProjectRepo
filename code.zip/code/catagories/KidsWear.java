package catagories;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class KidsWear {
	WebDriver driver;
	
	@Test(priority = 1)
	public void verifyProductDetails() {

	    boolean productName =
	            driver.getPageSource().contains("Kids");

	    List<WebElement> images =
	            driver.findElements(By.tagName("img"));

	    if(productName && images.size() > 0) {

	        System.out.println("PASS : Product details are displayed correctly");
	    }
	    else {

	        System.out.println("FAIL : Product details are missing");
	    }

	    Assert.assertTrue(productName && images.size() > 0);
	}
	
	@Test(priority = 2)
	public void verifyAddToCart() {

	    List<WebElement> buttons =
	            driver.findElements(
	                    By.xpath("//button[contains(text(),'Add')]"));

	    if(buttons.size() > 0) {

	        buttons.get(0).click();

	        System.out.println(
	                "PASS : Add To Cart button is clickable");
	    }
	    else {

	        System.out.println(
	                "FAIL : Add To Cart button is not clickable");
	    }

	    Assert.assertTrue(buttons.size() > 0);
	}
	
	@Test(priority = 3)
	public void verifyProductDetalpageNavigation() {

	    String oldUrl = driver.getCurrentUrl();

	    List<WebElement> images =
	            driver.findElements(By.tagName("img"));

	    if(images.size() > 0) {

	        images.get(0).click();

	        String newUrl =
	                driver.getCurrentUrl();

	        if(!oldUrl.equals(newUrl)) {

	            System.out.println(
	                    "PASS : Product details page opened");
	        }
	        else {

	            System.out.println(
	                    "FAIL : Product details page not available");
	        }
	    }
	}
	
	@Test(priority = 4)
	public void verifyWishlistButton() {

	    List<WebElement> wishButtons =
	            driver.findElements(
	                    By.xpath("//button[contains(@class,'wish')]"));

	    if(wishButtons.size() > 0) {

	        wishButtons.get(0).click();

	        System.out.println(
	                "PASS : Wishlist button is clickable");
	    }
	    else {

	        System.out.println(
	                "FAIL : Wishlist button is not clickable");
	    }
	}
	

	@Test(priority = 5)
	public void verifyCartAndWishlistWithoutLogin() {

	    boolean cartAdded = false;
	    boolean wishlistAdded = false;

	    try {

	        driver.findElements(
	                By.xpath("//button[contains(text(),'Add')]"))
	                .get(0).click();

	        cartAdded = !driver.getCurrentUrl().contains("login");

	    } catch(Exception e) {

	        cartAdded = false;
	    }

	    driver.navigate().back();

	    try {

	        driver.findElements(
	                By.xpath("//button[contains(@class,'wish')]"))
	                .get(0).click();

	        wishlistAdded = !driver.getCurrentUrl().contains("login");

	    } catch(Exception e) {

	        wishlistAdded = false;
	    }

	    System.out.println("Cart Added Without Login : " + cartAdded);
	    System.out.println("Wishlist Added Without Login : " + wishlistAdded);

	    Assert.assertTrue(cartAdded && wishlistAdded,
	            "User cannot add products to Cart/Wishlist without login");
	}
	
	 @AfterClass
	    public void closeBrowser() {

	        driver.quit();
	    }
		
  @BeforeClass
  public void setup() {

      driver = new ChromeDriver();
      driver.manage().window().maximize();
      driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

      driver.get("https://hexaclothes.netlify.app/");
      driver.findElement(By.xpath("//*[@id=\"root\"]/div[1]/div[1]/ul/li[3]/a")).click();
  }
}
