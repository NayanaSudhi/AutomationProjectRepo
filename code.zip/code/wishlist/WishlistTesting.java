package wishlist;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class WishlistTesting {
	
	WebDriver driver;
	
	  

  @Test (priority = 1)
  public void verifyWishlistPageLoadsSuccessfully() {

      Assert.assertTrue(driver.getCurrentUrl().contains("wishlist"));

      System.out.println("PASS : Wishlist page loaded successfully");
  }
  
  @Test(priority = 2)
  public void verifyWishlistHeaderDisplayed() {

      WebElement body = driver.findElement(By.tagName("body"));

      Assert.assertTrue(body.isDisplayed());

      System.out.println("PASS : Wishlist title/header displayed");
  }
  
  @Test(priority = 3)
  public void verifyProductImageDisplayed() {

      List<WebElement> images =
              driver.findElements(By.tagName("img"));

      Assert.assertTrue(images.size() > 0);

      System.out.println("PASS : Product image displayed");
  }
  
  @Test(priority = 4)
  public void verifyProductNameAndPriceDisplayed() {

      String pageSource = driver.getPageSource();

      Assert.assertTrue(pageSource.length() > 0);

      System.out.println("PASS : Product name and price displayed");
  }
  
  @Test(priority = 5)
  public void verifyRemoveProductFromWishlist() {

      List<WebElement> buttons =
              driver.findElements(By.tagName("button"));

      int before = buttons.size();

      if (before > 0) {

          buttons.get(0).click();

          System.out.println("PASS : Product removed from wishlist");
      }
  }
  
  @Test(priority = 6)
  public void verifyWishlistCountUpdate() {

      int count =
              driver.findElements(By.tagName("img")).size();

      System.out.println("Wishlist Product Count : " + count);
  }

  @Test(priority = 7)
  public void verifyAddToCartButtonDisplayed() {

      String source = driver.getPageSource();

      System.out.println("PASS : Add To Cart validation executed");

      Assert.assertNotNull(source);
  }

  @Test(priority = 8)
  public void verifyMoveWishlistProductToCart() {

      List<WebElement> buttons =
              driver.findElements(By.tagName("button"));

      if (buttons.size() > 0) {

          buttons.get(0).click();

          System.out.println("PASS : Product moved to cart");
      }
  }

  @Test(priority = 9)
  public void verifyProductRemainsOrRemovesFromWishlist() {

      // Capture product name before Add To Cart
      String expectedProduct = "Men Regular Fit Shirt"; // Replace with actual product

      List<WebElement> wishlistProducts =
              driver.findElements(By.xpath("//h6"));

      boolean productFound = false;

      for (WebElement product : wishlistProducts) {

          String actualProduct = product.getText().trim();

          if (actualProduct.equalsIgnoreCase(expectedProduct)) {

              productFound = true;
              break;
          }
      }

      if (productFound) {

          System.out.println("PASS : Product remains in wishlist after adding to cart");
          Assert.assertTrue(true);

      } else {

          System.out.println("PASS : Product removed from wishlist after adding to cart");
          Assert.assertTrue(true);
      }
  }

  @Test(priority = 10)
  public void removeAllProductsFromWishlist() throws InterruptedException {

      while (driver.findElements(
              By.xpath("//button[contains(@aria-label,'remove')]"))
              .size() > 0) {

          driver.findElement(
                  By.xpath("(//button[contains(@aria-label,'remove')])[1]"))
                  .click();

          Thread.sleep(1000);

          System.out.println("One product removed");
      }

      System.out.println("Wishlist is empty");
  }
  
  @Test(priority = 11)
  public void verifyEmptyWishlistMessageDisplayed() {

      String pageText = driver.findElement(By.tagName("body"))
                              .getText()
                              .toLowerCase();

      if(pageText.contains("wishlist is empty")) {

          System.out.println("EXPECTED RESULT : Empty wishlist message displayed");

          System.out.println("ACTUAL RESULT : " + pageText);

          Assert.assertTrue(true);

      } else {

          System.out.println("EXPECTED RESULT : Empty wishlist message displayed");

          System.out.println("ACTUAL RESULT : Empty wishlist message NOT found");

          Assert.fail("Empty wishlist message not displayed");
      }
  }
  
  

  @Test(priority = 11)
  public void verifyFooterDisplayed() {

      List<WebElement> footer =
              driver.findElements(By.tagName("footer"));

      Assert.assertTrue(footer.size() > 0);

      System.out.println("PASS : Footer displayed");
  }

  @AfterClass
  public void tearDown() {

      driver.quit();
  }

  
  
  @BeforeClass
  public void setup() throws InterruptedException {

      driver = new ChromeDriver();

      driver.manage().window().maximize();

      driver.manage().timeouts()
              .implicitlyWait(Duration.ofSeconds(10));
      
      // LOGIN
      driver.get("https://hexaclothes.netlify.app/");
      driver.findElement(By.xpath("//*[@id=\"root\"]/div[1]/nav/div[2]/a[3]/button")).click();
Thread.sleep(2000);
      driver.findElement(By.xpath("//input[@type='email']"))
              .sendKeys("sreelakshmi@gmail.com");

      driver.findElement(By.xpath("//input[@type='password']"))
              .sendKeys("sree@12345");

      driver.findElement(By.xpath("//*[@id=\"root\"]/div[1]/div[2]/form/button")).click();

      Thread.sleep(3000);

      System.out.println("Login Successful");
      
      // OPEN ALL PRODUCTS PAGE
      driver.findElement(By.xpath("//*[@id=\"root\"]/div[1]/div[1]/ul/li[6]/a")).click();

      Thread.sleep(3000);

      // ADD 3 PRODUCTS TO WISHLIST
      List<WebElement> wishlistButtons =
              driver.findElements(By.xpath(
                      "//button//*[name()='svg' or @data-testid='FavoriteBorderIcon']/.."));

      int count = 0;

      for (WebElement button : wishlistButtons) {

          if (count == 6) {
              break;
          }

          try {

              ((JavascriptExecutor) driver)
                      .executeScript("arguments[0].click();", button);

              count++;

              System.out.println("Product Added To Wishlist : " + count);

              Thread.sleep(6000);

          } catch (Exception e) {

              System.out.println("Unable To Add Product");
          }
      }

      // OPEN WISHLIST PAGE
      driver.findElement(By.xpath("//*[@id='root']/div[1]/nav/div[2]/a[1]")).click();
      Thread.sleep(3000);

  }
}
