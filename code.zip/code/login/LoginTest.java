package login;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class LoginTest {
	 WebDriver driver;
	    WebDriverWait wait;

	    @BeforeMethod
	    public void beforeMethod() {

	        driver = new ChromeDriver();
	        driver.manage().window().maximize();

	        wait = new WebDriverWait(driver, Duration.ofSeconds(10));

	        driver.get("https://hexaclothes.netlify.app/");
	    }

	    

	    @Test(priority = 1)
	    public void testSuccessfulLogin() throws InterruptedException {


	        WebElement Login = wait.until(
	                ExpectedConditions.elementToBeClickable(
	                        By.cssSelector("a[href='/login'] button")));

	        Login.click();

	        driver.findElement(By.id("email"))
	                .sendKeys("sreelakshmi@gmail.com");

	        driver.findElement(By.id("password"))
	                .sendKeys("sree@12345");

	        System.out.println("Email Entered : sreelakshmi@gmail.com");
	        System.out.println("Password Entered : ********");

	        driver.findElement(
	                By.xpath("//*[@id='root']/div[1]/div[2]/form/button"))
	                .click();

	        WebElement logout = wait.until(
	                ExpectedConditions.visibilityOfElementLocated(
	                        By.xpath("//*[@id='root']/div[1]/nav/div[2]/button")));

	        if (logout.isDisplayed()) {

	            System.out.println("Logout Button Displayed : true");
	            System.out.println("PASS : User Logged In Successfully");

	        } else {

	            System.out.println("FAIL : Login Failed");
	        }

	        Thread.sleep(2000);
	    }

	    @Test(priority = 2)
	    public void loginButton() {

	        driver.get("https://hexaclothes.netlify.app/login");

	        WebElement loginBtn =
	                driver.findElement(By.xpath(
	                        "//*[@id='root']/div[1]/div[2]/form/button"));

	        System.out.println(
	                "Login Button Displayed : "
	                        + loginBtn.isDisplayed());

	        System.out.println(
	                "Login Button Enabled : "
	                        + loginBtn.isEnabled());

	        if (loginBtn.isDisplayed()
	                && loginBtn.isEnabled()) {

	            System.out.println(
	                    "PASS : Login Button Working Properly");

	        } else {

	            System.out.println(
	                    "FAIL : Login Button Not Working");
	        }
	    }

	    @Test(priority = 3)
	    public void eyeToggle() throws InterruptedException {

	        driver.get("https://hexaclothes.netlify.app/login");

	        WebElement password =
	                driver.findElement(By.id("password"));

	        password.sendKeys("sree@12345");

	        String beforeToggle =
	                password.getAttribute("type");

	        WebElement eyeToggle =
	                driver.findElement(By.xpath(
	                        "//*[@id='root']/div[1]/div[2]/form/div[2]/button"));

	        eyeToggle.click();

	        String afterToggle =
	                password.getAttribute("type");

	        System.out.println(
	                "Before Toggle : " + beforeToggle);

	        System.out.println(
	                "After Toggle : " + afterToggle);

	        if (beforeToggle.equals("password")
	                && afterToggle.equals("text")) {

	            System.out.println(
	                    "PASS : Password Visible After Toggle");

	        } else {

	            System.out.println(
	                    "FAIL : Eye Toggle Not Working");
	        }

	        Thread.sleep(2000);
	    }

	    @Test(priority = 4)
	    public void dontHaveAnyAccountMessage() {


	        driver.get("https://hexaclothes.netlify.app/login");

	        WebElement message = wait.until(
	                ExpectedConditions.visibilityOfElementLocated(
	                        By.xpath("//*[@id='root']/div[1]/div[2]/div/p")));

	        String actualMessage = message.getText();

	        String expectedMessage =
	                "Don't have an account?";

	        System.out.println(
	                "Expected Message : "
	                        + expectedMessage);

	        System.out.println(
	                "Actual Message : "
	                        + actualMessage);

	        if (actualMessage.contains(expectedMessage)) {

	            System.out.println(
	                    "PASS : Message Displayed Correctly");

	        } else {

	            System.out.println(
	                    "FAIL : Message Not Displayed");
	        }
	    }

	    @Test(priority = 5)
	    public void registrationLink() {

	        driver.get("https://hexaclothes.netlify.app/login");

	        WebElement registrationLink =
	                driver.findElement(
	                        By.xpath("//*[@id='root']/div[1]/div[2]/div/p/a"));

	        registrationLink.click();

	        String actualUrl =
	                driver.getCurrentUrl();

	        String expectedUrl =
	                "https://hexaclothes.netlify.app/register";

	        System.out.println(
	                "Expected URL : "
	                        + expectedUrl);

	        System.out.println(
	                "Actual URL : "
	                        + actualUrl);

	        if (actualUrl.equals(expectedUrl)) {

	            System.out.println(
	                    "PASS : Registration Link Working");

	        } else {

	            System.out.println(
	                    "FAIL : Registration Link Failed");
	        }
	    }

	    

	    @Test(priority = 6)
	    public void testEmailFormat() {

	        driver.get("https://hexaclothes.netlify.app/login");

	        driver.findElement(By.id("email"))
	                .sendKeys("sreelakshmi");

	        driver.findElement(
	                By.xpath("//*[@id='root']/div[1]/div[2]/form/button"))
	                .click();

	        System.out.println(
	                "Entered Email : sreelakshmi");

	        System.out.println(
	                "PASS : Invalid Email Validation Triggered");
	    }

	    @Test(priority = 7)
	    public void passwordFormat() {

	        driver.get("https://hexaclothes.netlify.app/login");

	        driver.findElement(By.id("email"))
	                .sendKeys("sreelakshmi@gmail.com");

	        driver.findElement(By.id("password"))
	                .sendKeys(
	                        "abcdefghijklmnopqrstuvxyz1234567890!@#$%^&*(");

	        driver.findElement(
	                By.xpath("//*[@id='root']/div[1]/div[2]/form/button"))
	                .click();

	        System.out.println(
	                "PASS : Invalid Password Validation Checked");
	    }

	    @Test(priority = 8)
	    public void emptyEmailField() {

	        driver.get("https://hexaclothes.netlify.app/login");

	        driver.findElement(By.id("password"))
	                .sendKeys("sree@12345");

	        driver.findElement(
	                By.xpath("//*[@id='root']/div[1]/div[2]/form/button"))
	                .click();

	        System.out.println(
	                "Email Field Left Empty");

	        System.out.println(
	                "PASS : Empty Email Validation Verified");
	    }

	    @Test(priority = 9)
	    public void emptyPasswordField() {


	        driver.get("https://hexaclothes.netlify.app/login");

	        driver.findElement(By.id("email"))
	                .sendKeys("sreelakshmi@gmail.com");

	        driver.findElement(
	                By.xpath("//*[@id='root']/div[1]/div[2]/form/button"))
	                .click();

	        System.out.println(
	                "Password Field Left Empty");

	        System.out.println(
	                "PASS : Empty Password Validation Verified");
	    }

	    @Test(priority = 10)
	    public void validEmailIncorrectPassword() {

	        driver.get("https://hexaclothes.netlify.app/login");

	        driver.findElement(By.id("email"))
	                .sendKeys("sreelakshmi@gmail.com");

	        driver.findElement(By.id("password"))
	                .sendKeys("abcdefg123");

	        driver.findElement(
	                By.xpath("//*[@id='root']/div[1]/div[2]/form/button"))
	                .click();

	        System.out.println(
	                "Email : sreelakshmi@gmail.com");

	        System.out.println(
	                "Password : abcdefg123");

	        System.out.println(
	                "PASS : Invalid Credentials Validation Verified");
	    }

	    @Test(priority = 11)
	    public void emptyAllFields() {

	        driver.get("https://hexaclothes.netlify.app/login");

	        driver.findElement(
	                By.xpath("//*[@id='root']/div[1]/div[2]/form/button"))
	                .click();

	        System.out.println(
	                "Email Field Empty");

	        System.out.println(
	                "Password Field Empty");

	        System.out.println(
	                "PASS : Empty Fields Validation Verified");
	    }

	    @AfterMethod
	    public void afterMethod() {

	        if (driver != null) {
	            driver.quit();
	        }
	    }
	}

